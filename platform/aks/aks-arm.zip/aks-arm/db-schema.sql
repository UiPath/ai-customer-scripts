GO
CREATE USER [USERNAME_VAR_helper] FOR LOGIN  [USERNAME_VAR_helper] WITH DEFAULT_SCHEMA = ai_helper
GO
CREATE SCHEMA ai_helper AUTHORIZATION [USERNAME_VAR_helper]
GO
EXEC sp_addrolemember 'db_ddladmin', 'USERNAME_VAR_helper';
GO
GO
CREATE USER [USERNAME_VAR_pkgmanager] FOR LOGIN  [USERNAME_VAR_pkgmanager] WITH DEFAULT_SCHEMA = ai_pkgmanager
GO
CREATE SCHEMA ai_pkgmanager AUTHORIZATION [USERNAME_VAR_pkgmanager]
GO
EXEC sp_addrolemember 'db_ddladmin', 'USERNAME_VAR_pkgmanager';
GO
GO
CREATE USER [USERNAME_VAR_deployer] FOR LOGIN  [USERNAME_VAR_deployer] WITH DEFAULT_SCHEMA = ai_deployer
GO
CREATE SCHEMA ai_deployer AUTHORIZATION [USERNAME_VAR_deployer]
GO
EXEC sp_addrolemember 'db_ddladmin', 'USERNAME_VAR_deployer';
GO
GO
CREATE USER [USERNAME_VAR_trainer] FOR LOGIN  [USERNAME_VAR_trainer] WITH DEFAULT_SCHEMA = ai_trainer
GO
CREATE SCHEMA ai_trainer AUTHORIZATION [USERNAME_VAR_trainer]
GO
EXEC sp_addrolemember 'db_ddladmin', 'USERNAME_VAR_trainer';
GO
GO
CREATE USER [USERNAME_VAR_appmanager] FOR LOGIN  [USERNAME_VAR_appmanager] WITH DEFAULT_SCHEMA = ai_appmanager
GO
CREATE SCHEMA ai_appmanager AUTHORIZATION [USERNAME_VAR_appmanager]
GO
EXEC sp_addrolemember 'db_ddladmin', 'USERNAME_VAR_appmanager';
GO